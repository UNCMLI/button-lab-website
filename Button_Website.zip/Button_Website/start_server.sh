#!/usr/bin/env bash
# Start a local HTTP server for the Button Lab website.
# Needed because browsers block fetch() of local .json files over file://
set -euo pipefail

cd "$(dirname "$0")"

PORT="${1:-8000}"
URL="http://localhost:${PORT}/index.html"

# Stop any previous instance of this server on the same port
if lsof -ti tcp:"${PORT}" >/dev/null 2>&1; then
    echo "Port ${PORT} is already in use. Stopping that process..."
    lsof -ti tcp:"${PORT}" | xargs kill
    sleep 1
fi

python3 serve.py "${PORT}" >/dev/null 2>&1 &

echo "Server running at ${URL}"
echo "Press Ctrl+C to stop."
echo ""

# Wait a moment for the server to start, then open the browser
sleep 1
open "${URL}"

wait
